from setuptools import setup

setup(name='distributions_test_udacity_AA',
      version='0.1',
      description='Gaussian distributions',
      packages=['distributions'],
      zip_safe=False)
